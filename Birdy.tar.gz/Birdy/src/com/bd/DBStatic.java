package com.bd;

public class DBStatic {
	
//	public static boolean pooling = false;
//	public static String mysql_host = "localhost";
//	public static String mysql_db = "sotiroski";
//	public static String mysql_user = "root";
//	public static String mysql_password = "root";
	
	public static boolean pooling = false;
	public static String mysql_host = "localhost";
	public static String mysql_db = "sotiroski";
	public static String mysql_user = "root";
	public static String mysql_password = "root";
	
}
